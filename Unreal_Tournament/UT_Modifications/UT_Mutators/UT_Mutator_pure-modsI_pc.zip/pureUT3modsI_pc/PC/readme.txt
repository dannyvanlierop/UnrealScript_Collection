Just copy and merge the 'My Games' folder from the 'pureUT3modsI - PC' folder to the following directory:

\Users\*UsernameHere*\My Documents\My Games

You should be able to use the mods under the mutator list before starting the game.

