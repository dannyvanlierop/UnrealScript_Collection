Just open the folder that is your platform of choice that you want to
install the mod for UT3. Inside the PC folder, you will see install instructions
and the folder with the mods files.