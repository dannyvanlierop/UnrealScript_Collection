Thank you for downloading Mutators2014 V.1.1.
In this file, I will explain you how to install the Mutators.

Check out http://www.moddb.com/mods/mutators-2014 for questions and help.

Changelog V 1.1
-Instagib fixed
-Grenade/Sniper fixed
-Invisible Mutator added

1)
Extract the Mutators2014.u file and put it in your properties folder. It should be located
in C:\Program Files (x86)\LucasArts\Star Wars Republic Commando\GameData.

(If you dont want to edit any files, skip to step 5)

2)
After you placed the file in the properties folder, go to the system folder and search for a file
called xGameList. Now it depends on which version of the game you have. The english version uses
the file extension ".int", the german version uses ".det" and the french version uses ".fr".
For example I have the german version so I open xGameList.det file. If you have the english or
french version, open xGameList.int or xGameList.fr file.

3)
When you opened the file you will see 4 lines. I will put a part of the first line here:

GameType=(GameName="DeathMatch",ClassName="MPGame.DMGame",MapPrefix=....

Now we are adding the mutator to the class by adding behind MPGame.DMGame?mutator=Mutators2014.Instagib.

At the end it should look like this:
ClassName="MPGame.DMGame?Mutator=Mutators2014.Instagib",

Be sure you write everything correct otherwise it won't load the mutator or the worst thing could happen is a gamecrash while trying to load!

If you want to play another mutator, just replace instagib with the following:
NoNoob      ?Mutator=Mutators2014.NoNoob
LowGrawity  ?Mutator=Mutators2014.LowGravity
Menace      ?Mutator=Mutators2014.Menace   
GameSpeed   ?Mutator=Mutators2014.GameSpeed
SlomoDeath  ?Mutator=Mutators2014.SlomoDeath
Regenerate  ?Mutator=Mutators2014.Regenerate
Invisible   ?Mutator=Mutators2014.Invisible

DON'T TRY TO LOAD MORE THAN ONE MUTATOR AT THE SAME TIME OTHERWISE YOUR GAME WILL CRASH!!!

You can add a mutator to every gamemode if you want.

4)
If you are done adding mutators save the file and start the game. Create Lan or Internet Game and the mutator will be loaded.

5)Alternative way
If you dont want to edit any files because of any reason, you can load the mutator from ingame console. Don't forget to place the mutators2014.u file in the properties folder. Start your game, create a lan or internet game and open your console. (USA: ~   GERMAN:  ^) If you cannot open your console, ask google :). Now write:  open dm_canyon?mutator=Mutators2014.Instagib
What it does is opening the map gunship with the mutator instagib. Go to step 3 to see what mutators you can add. Don't try to load more than one mutator at the same time otherwise your game will crash!

MapList for console:
dm_canyon          = Gunship
dm_siege           = Arena A17       ctf_siege
dm_zerog           = Arena G9        ctf_zerog
dm_pow             = Garrison        ctf_pow
dm_powsmall        = Depot
dm_detention       = Lockdown        ctf_detention
dm_engine          = Engine          ctf_engine
dm_underpass       = Kachiroh        ctf_underpass
dm_hanginggarden   = Garden          ctf_hanginggarden
dm_trando          = Ghostship       ctf_trando
dm_hangar          = Hangar          ctf_hangar



Have Fun playing the mutators. If you have questions or problems, go to http://www.moddb.com/mods/mutators-2014
Or add me here:

xFire: arceus83
skype: arceus83
steam: plasma113