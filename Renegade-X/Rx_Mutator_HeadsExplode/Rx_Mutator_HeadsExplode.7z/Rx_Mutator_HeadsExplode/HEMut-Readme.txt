_-��-__-��-__-��-__-��-__-��-__-��-__-��-__-��-__-��-__-��-__-��-_
�	 SlayR Industries feat. DudeMuts proudly presents	 �
								 
			Heads Explode				 
			 the Mutator				 

			 by  dP^Dude
_								 _
�-__-��-__-��-__-��-__-��-__-��-__-��-__-��-__-��-__-��-__-��-__-�


Content:
--------
	needed files:
		HeadExplo.int
		HeadExplo.u
	
	script files (these contain the code for the mutator):
		HeadsExplodeRules.uc
		MutHeadExplo.uc
		HeadShrinkPill.uc
		HeadExplodeMessage.uc

	other files:
		HEMut-Readme.txt (if you didn't knew this already...)


Installation:
-------------
	Unpack the HeadExplo.u and HeadExplo.int into your
	Unreal Tournamen 2003 System directory.
	Then you can choose the new mutator in the mutator
	menu available in game.

Description: 
------------
	"Heads Explode" is a mutator that lets your head grow.
	When it has reached a certain volume it will blow up
	and kill you and the other unlucky ones around you. But
	you can do something against this! Either you collect
	the "Head Shrink Pills" that you can find throughout the
	map (they replace the "Adrenaline" on the map) or you
	shrink your head by killing people! Every time you kill
	someone your head shrinks and you get extra rewards for 
	killing	sprees or multiple kills.
	This mutator just adds a little more action to the whole
	gameplay and you can easily see if you should avoid an
	enemy, because he'll explode in a few seconds.

Hints:
------
	Take out enemies with big heads from far away, because you'll
	never now when the newb will splatter and keep on killing
	as fast as possible to prevent an explosion that kills you
	and counts as a suicide.

Miscellaneous:
--------------
	Feel free look into the script files I've included into the
	pack. They're commented so that beginners who want to learn
	UScript can see how the things work and understand the script
	easy.

Known Issues:
-------------
	I've only tested the mutator offline and didn't try it on a
	server so I don't know if there are multiplayer issues.

	If you think find any bugs please report them to me. (Info below)

Credits:
--------
	Idea and Code by:
		SlayR aka dP^Dude
		SlayR@t-online.de

	Thanks to:
		all the people from the BeyondUnreal Coding Forum that
		helped me to get rid of an annoying bug.

	Visit Digital Perfection at http://www.islandncs.com/digitalperfection/forums/
	


